<?php
$view = new stdClass();
$view->pageTitle = 'Homepage';

require_once("logincontroller.php");




require_once('Views/index.phtml');
